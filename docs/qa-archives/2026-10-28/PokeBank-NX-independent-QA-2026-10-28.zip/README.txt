PokeBank NX independent QA evidence archive — 2026-10-28

NOT APPLIED, NOT MERGED, NOT HARDWARE VALIDATED.
This ZIP is an archival copy of two Claude API QA campaigns, not a release or an instruction to deploy the patches.
Campaign 1: Gen IV Bag Remove compaction proof/fix/regression tests.
Campaign 2: Gen IV Berry/TM Add sorting plus upstream PKSE #147 receiving Handling Trainer proof/fix/regression tests.

BEFORE INTEGRATION: review both change sets on a fresh branch; do not double-apply standalone patches + combined series.
The #147 handler fix has known open risks around receiving save language, friendship and memories; do NOT deploy without a complete destination-trainer context and separate validation.
Keep Japanese Gen I/II editing locked, legality PR #314 excluded, and original game saves immutable.

Files preserved below byte-for-byte from user-uploaded QA artifacts. See MANIFEST.sha256; original campaign 2 SHA256SUMS.txt covers more files than are bundled here.
