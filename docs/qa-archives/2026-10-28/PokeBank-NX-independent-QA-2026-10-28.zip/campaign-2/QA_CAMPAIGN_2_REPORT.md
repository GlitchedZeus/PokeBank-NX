# PokeBank NX QA Campaign 2 Report

Tested branch: origin/integration/gen15-combined, HEAD **c4f414a3d08aaf73ab7fc0ce7b59f28316045d59** (unchanged since last known).
QA branch: qa2/work (local only, nothing pushed). Host: g++ (GCC), Makefile.host.

## Fixed: F1 — Gen IV Add does not sort Berry and TM/HM pockets (DP, Pt, HGSS)
- Function: `Gen4StagedPokemonEditor::stageBagAdd` (src/Integration/Gen4/Gen4StagedPokemonEditor.cpp).
- Native evidence: pret/pokeplatinum `Bag_TryAddItem` and pret/pokeheartgold `Bag_AddItem` call the pocket sort after every Add,
  only for POCKET_BERRIES and POCKET_TMHMS (ascending item ID, empties last). Copies of the source files: `ref_pokeheartgold_bag.c`, `ref_pokeplatinum_bag.c`.
  DP evidence is by analogy (no DP decomp was consulted); the app's Gen IV Add shares one code path and the same pocket logic.
- Repro: add Berries 155,150,152 → before fix stored [155,150,152]; after fix [150,152,155]. TMs 330,420,328,329 → [328,329,330,420]. Items pocket stays append order (native does not sort it).
- Fix: for Berries/Machines only, if the pocket is well-formed (occupied slots are a packed prefix, trailing slots are native blank sentinels, no ghost slots) rewrite the pocket's slots in ID-sorted order. Otherwise fall back to the old append so malformed slots are never silently rewritten. No sorting on load. Quantities and identities preserved. Byte audit now permits changes only inside that pocket's slot range plus the General CRC.
- Tests: new `testGen4BagAddSortsBerriesAndMachinesLikeNativeGames` (tests/test_gen4_staged_pokemon_editor.cpp) covers all three layouts, other pockets unchanged, blank tails, a full 64-berry pocket filled in descending order, full-pocket refusal being byte-inert, and Discard. FAILED before (`gen4_sort_before.log`: assertion `ids(berries) == wantB`), PASSES after (`gen4_sort_after.log`).
- Existing test `test_gen4_readonly_foundation.cpp` encoded the old append order for TM/HM (HM01 added before TM01 shown at index 0). It was updated to the native order; this is an intentional expectation change.
- Results: full `make -f Makefile.host host-test` rc=0 (-k, after the test update); ASan+UBSan builds of test_gen4_staged_pokemon_editor and test_gen4_readonly_foundation PASS (`gen4_sanitize.log`). Clang not run.
- Local commits: test 39431be25d868b18a17740e076c748cb1954f341, fix 7b164d704923a812146e222a8301735924119a36, test update 62b76716 (HEAD).
- Not tested: ghost-slot / pre-existing-unsorted-pocket fallback has no dedicated test (code-reviewed only); Remove→Add interaction was not tested because the Remove compaction fix is not in this branch. Hardware not validated.

## Outstanding known issue (not a new discovery)
Gen IV Remove still leaves an interior hole on this branch (stageBagRemove writes zeros without compacting); the previous campaign's patch is not integrated. Note: after it is integrated, native pockets (Berries/TM) are sorted after Add and compacted after Remove; apply both patches together and re-run the new test.

## Gen V Bag (Priority A) — unresolved, no change made
`Gen5StagedBag` (include/Integration/Gen5/Gen5Bag.h) removes by zeroing the slot, reuses interior empty slots on Add, and doesn't sort. I found no public Gen V decompilation to establish whether BW/B2W2 compact or sort pockets, and no emulator available. The Gen IV decomp behavior must not be assumed for Gen V. Uncertainty: whether the game compacts after removal, whether Berries/TMs are sorted in BW/B2W2, and whether interior holes render/behave correctly in-game. Needs hardware/emulator experiment (remove interior item in a clean BW and B2W2 save, open Bag, add item, compare). Existing code audits only the 4 changed bytes in the Items block; I did not audit the Gen V checksum path.


## Fixed (addendum): F2 — Receiving trainer never becomes handler on cross-game withdrawal (upstream PKSE#147)
- Audit: `Conversion::convert` has no destination-trainer input; the only HT handling is a verbatim copy of existing HT/CurrentHandler fields (Convert.cpp PK8<->PA8, PB7). The single production call site, `TrainerViewScreen::prepareForPane` (src/UI/TrainerViewScreenBase.inc), never set a handler. Result: FRLG -> SwSh/BDSP/SV candidates had HT empty and the OT as active handler (the "HT (none)" report). Verified in the new test as a characterization (`htName().empty() && currentHandler()==0` right after convert()).
- Fix: new `Conversion::applyReceivingHandler(pk, ReceivingTrainer)` (include/Conversion/Convert.h, src/Conversion/Convert.cpp), called only on the disposable converted candidate in prepareForPane. Rules, following the issue's description of PKHeX (PK5.ConvertToPK6 / PKH.UpdateHandler/IsHandlerSame) — I did not re-read PKHeX source line by line, so exact parity is unverified:
  - receiver == OT (id32+name+gender): CurrentHandler=0, HT bytes untouched;
  - existing HT == receiver: CurrentHandler=1, HT bytes untouched (repeat withdrawals are byte-idempotent);
  - otherwise HT name+gender := receiver, CurrentHandler=1; OT/TID/SID/origin/met/language never touched;
  - empty name, gender>1 or a name the format cannot store exactly (e.g. >12 chars) -> `ContextUnavailable`, mon untouched, and prepareForPane REFUSES the placement with a message (fails safe, nothing invented);
  - Gen 3 FR/LG has no handler -> NotApplicable. Same-group placements and Bank custody are untouched (handler preserved).
- HT language: the app does not parse the receiving save's language (only FRLG does), so HT language is NOT written (stays 0) unless a caller supplies it. Added `htLanguage/setHTLanguage` virtuals (PK8/BDSP/SV/ZA 0xC3, PA8 0xD3; PB7 has none). **Open risk:** a nonzero HT name with HT language 0 may still be flagged by PKHeX; the app needs a trusted receiving-language source (needs hardware/save-format work). HT friendship/memories are also deliberately not altered (PKHeX/HOME may reset them) — unverified.
- Test: new block `issue147-receiving-handler` in tests/test_conversion_entity_golden.cpp (FRLG->SWSH/BDSP/SV, repeat withdrawal, different receiver, receiver==OT, fail-safe cases, PB7/PLA/ZA native offsets, Gen3 N/A). Before: compile failure against c4f414a3 (`issue147_before.log`, API absent); after: PASS; ASan+UBSan PASS (`issue147_after_sanitize.log`); full `host-test` rc=0.
- Not covered: LGPE<->SwSh etc. routes beyond direct apply; SM/USUM exception is N/A (not supported games); UI path not host-run (only compiled in host-ui tests that passed); no hardware validation. Local commit 1c4a5ea187598206461ceed3be361ae7bbc79e96.

## Upstream issues recorded for future work
- **PKSE#145 (LGPE Lure/catch-combo encounter level, "+1")**: record as a future Gen VII legality regression requirement. I did not verify the +1 rule against game evidence and made no code change; the issue text is ambiguous on game (title LGPE, body labelled FireRed/LeafGreen). No legality engine integrated; PR #314 untouched.
- **PKSE#48 (ribbon editing)**: future enhancement; not required for the Gen I-V hardware candidate. Existing conversion code already refuses unrepresentable ribbons (`RibbonMarkNotRepresentable`) and reports losses; I did not re-audit ribbon preservation this session beyond the full host suite passing.

## Not investigated (budget/time focus)
Priorities C (Gen III/V fuzzing campaign), D (import/export fidelity), E (Bank recovery). No new findings are claimed for them. Existing fuzz harnesses are in tests/fuzz_*.cpp.

## Recommended next
1. Integrate previous Remove-compaction patch + this one; 2. Emulator-verify Gen V remove/add behavior; 3. Dedicated ghost-slot fallback test; 4. Priorities C/D/E.

## Artifacts
fix-gen4-native-berry-tm-sort.patch, fix-issue147-receiving-handler.patch, regression-test-issue147-receiving-handler.patch, issue147_*.log, regression-tests-gen4-native-sort.patch, qa-campaign-2-series.patch (applies cleanly with `git apply --check` to c4f414a3), qa-campaign-2.bundle, logs, ref_*.c, PROVENANCE.txt, SHA256SUMS.txt.
